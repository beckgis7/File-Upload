import { CalendarModule } from './../../calendar/calendar.module';
import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";

import { ConsultationRoutingModule } from "./consultation-routing.module";
import { ConsultationComponent } from "./consultation.component";
import { SharedModule } from "src/app/theme/shared/shared.module";
// Services
import { FileUploadService } from './services/file-upload.service';
// Components
import { FileUploadComponent } from './file-upload/file-upload.component';
import { FilesViewComponent } from './files-view/files-view.component';


import {
  NgbModule,
  NgbPopoverModule,
  NgbTooltipModule,
  NgbAccordionModule,
  NgbCollapseModule,
  NgbDropdownModule,
  NgbButtonsModule,
} from "@ng-bootstrap/ng-bootstrap";
import {
  FormsModule,
  ReactiveFormsModule,
  FormGroup,
  FormBuilder,
} from "@angular/forms";
import { DataTablesModule } from "angular-datatables";
import { CustomFormsModule } from "ngx-custom-validators";
import { NgSelectModule } from "@ng-select/ng-select";
import { FullCalendarModule } from "@fullcalendar/angular";

import { SelectDropDownModule } from "ngx-select-dropdown";
import { ConsultationFormComponent } from "./consultation-form/consultation-form.component";
import { NgxSpinnerModule } from "ngx-spinner";
import { NgxDropzoneModule } from "ngx-dropzone";
// import { NgxIntlTelInputModule } from "ngx-intl-tel-input";

@NgModule({
  declarations: [
    ConsultationComponent,
    ConsultationFormComponent,
    FileUploadComponent,
    FilesViewComponent,
  ],
  imports: [
    CommonModule,
    ConsultationRoutingModule,
    SharedModule,
    CalendarModule,
    FormsModule,
    ReactiveFormsModule,
    DataTablesModule,
    CustomFormsModule,
    NgbModule,
    NgbPopoverModule,
    NgbTooltipModule,
    NgbCollapseModule,
    NgbAccordionModule,
    FullCalendarModule,
    NgbDropdownModule,
    NgbButtonsModule,
    NgSelectModule,
    SelectDropDownModule,
    NgxDropzoneModule,
    // BsDropdownModule.forRoot(),
    // NgxIntlTelInputModule,
    NgxSpinnerModule,
  ],
  providers: [FileUploadService],
})
export class ConsultationModule {}
