import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { ConsultationComponent } from "./consultation.component";

const routes: Routes = [
  {
    path: "amendments",
    component: ConsultationComponent,
  },
  {
    path: "archive",
    component: ConsultationComponent,
  },
  {
    path: "",
    component: ConsultationComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ConsultationRoutingModule {}
