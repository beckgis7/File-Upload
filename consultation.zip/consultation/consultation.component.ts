/*
| -------------------------------------------------------------------
 |             STEPS TO CHANGE THIS FILE
 | -------------------------------------------------------------------
 |  1. Import form component for this component
 |  2. Make form component as view child
 |  3. Change api routes for database functions
 |  ie.
 |     checkAmendment
 |     getSpecimens
 |     getSpecimenArchives
 |     getSpecimenAmendments
 |     createSpecimen
 |     editSpecimen
 |     amendSpecimen
 |     softDeleteSpecimen
 |     permamentDeleteSpecimen
 |     restoreSpecimen
 |
 | -------------------------------------------------------------------
 |                      END OF STEPS
 | -------------------------------------------------------------------
 */

import { Component, OnDestroy, OnInit, Output, ViewChild, EventEmitter } from "@angular/core";
import { NgxSpinnerService } from "ngx-spinner";
import { AlertService } from "src/app/others/services/alert.service";
import { AuthenticationService } from "src/app/others/services/authentication.service";
import Swal, { SweetAlertOptions } from "sweetalert2";
import { Subject } from "rxjs";
import { DataTableDirective } from "angular-datatables";
import { ActivatedRoute, Router } from "@angular/router";
import { ConsultationFormComponent } from "./consultation-form/consultation-form.component";
import { FileUploadService } from "./services/file-upload.service";
import * as _ from "lodash";

@Component({
  selector: "app-consultation",
  templateUrl: "./consultation.component.html",
  styleUrls: ["./consultation.component.scss"],
})
export class ConsultationComponent implements OnInit, OnDestroy {
  // Make form component as view child [change]
  @ViewChild("form") form: ConsultationFormComponent;
  @ViewChild("modalView") viewModal;
  @Output() uploaded = new EventEmitter();
  files: Array<any> = [];

  // specimen data
  specimen: any = {}; //holds single selected specimen's data
  specimens: any = []; //holds array of specimens data

  // holds company data
  comData: any;

  // patient data
  patient: any = {}; //holds single selected patient's data
  patients: any = []; //holds array of patients data
  selected_patient = null;
  isSelected = false;
  patientsBuffer = [];
  bufferSize = 50;
  numberOfItemsFromEndBeforeFetchingMore = 10;
  loading = false;
  // holds the action to be performed ie(create/edit/amend/view)
  action: string;

  // holds the current page ie(root/archive/amendments)
  page: string = "root";

  // Url
  parentUrl = this.router.url; //holds the parent url
  amendmentsUrl = this.parentUrl + "/amendments"; //holds the amendments url
  archiveUrl = this.parentUrl + "/archive"; //holds archive url

  // boolean varaibles
  isLoading = false;
  isAmended = false;
  age: any;
  dateAge = "12/01/1991";

  // ================================Angular Table=====================================

  // angular table options
  dtOptions: DataTables.Settings = {
    pagingType: "full_numbers",
    pageLength: 25,
    serverSide: true,
    processing: true,
    ordering: false,
  };
  dtTrigger: Subject<any> = new Subject(); //triggers table initialization after every data load

  @ViewChild(DataTableDirective, { static: false })
  dtElement: DataTableDirective; //get the instance of the table being used

  isDtInitialized: boolean = false; //holds state of table to prevents multiple initialization

  // ==================================================================================

  actionButtons = true;

  permissions: any = [];

  serialize = function (obj, prefix?) {
    var str = [],
      p;
    for (p in obj) {
      if (obj.hasOwnProperty(p)) {
        var k = prefix ? prefix + "[" + p + "]" : p,
          v = obj[p];
        str.push(
          v !== null && typeof v === "object"
            ? this.serialize(v, k)
            : encodeURIComponent(k) + "=" + encodeURIComponent(v)
        );
      }
    }
    return str.join("&");
  };

  constructor(
    public auth: AuthenticationService,
    private alert: AlertService,
    private spinner: NgxSpinnerService,
    private route: ActivatedRoute,
    private router: Router,
    private fileUploadService: FileUploadService
  ) {}

  ngOnInit() {
    this.getPermissions();
    // Set the current page
    this.setPage();

    // Get company data
    this.getComProfile();

    //check the page and load the corresponding data
    switch (this.page) {
      case "archive":
        this.getSpecimenArchives();
        break;
      case "amendments":
        this.getSpecimenAmendments();
        break;
      default:
        this.getPatients();
        this.getSpecimens();
        break;
    }
  }

  getPermissions() {
    this.permissions = {
      clinicalModules: {
        add: false,
        edit: false,
        delete: false,
        view: false,
      },
    };

    this.auth
      .get("user_permissions/" + sessionStorage.getItem("userID"))
      .subscribe(
        (response: any) => {
          this.permissions = response.permissions.permissions[0];
        },
        (error: any) => {}
      );
  }

  ngOnDestroy(): void {
    // Do not forget to unsubscribe the event
    this.dtTrigger.unsubscribe();
  }

  onScrollToEnd() {
    this.fetchMore();
  }

  onScroll({ end }) {
    if (this.loading || this.patients.length <= this.patientsBuffer.length) {
      return;
    }

    if (
      end + this.numberOfItemsFromEndBeforeFetchingMore >=
      this.patientsBuffer.length
    ) {
      this.fetchMore();
    }
  }

  private fetchMore() {
    const len = this.patientsBuffer.length;
    const more = this.patients.slice(len, this.bufferSize + len);
    this.loading = true;
    // using timeout here to simulate backend API delay
    setTimeout(() => {
      this.loading = false;
      this.patientsBuffer = this.patientsBuffer.concat(more);
    }, 20);
  }

  public ageFromDOB(dateOfBirth: any): number {
    let now = new Date();
    let today = new Date(now.getFullYear(), now.getMonth(), now.getDate());

    let yearNow = now.getFullYear();
    let monthNow = now.getMonth();
    let dateNow = now.getDate();

    if (dateOfBirth == null) {
      dateOfBirth = "null";
    }

    let dob = new Date(
      dateOfBirth.substr(0, 4),
      dateOfBirth.substr(5, 2) - 1,
      dateOfBirth.substr(8, 2)
    );

    let yearDob = dob.getFullYear();
    let monthDob = dob.getMonth();
    let dateDob = dob.getDate();

    let yearString = "";
    let monthString = "";
    let dayString = "";
    let dateAge;
    let monthAge;

    let yearAge = yearNow - yearDob;

    if (monthNow >= monthDob) monthAge = monthNow - monthDob;
    else {
      yearAge--;
      monthAge = 12 + monthNow - monthDob;
    }

    if (dateNow >= dateDob) dateAge = dateNow - dateDob;
    else {
      monthAge--;
      dateAge = 31 + dateNow - dateDob;

      if (monthAge < 0) {
        monthAge = 11;
        yearAge--;
      }
    }

    let age = {
      years: yearAge,
      months: monthAge,
      days: dateAge,
    };

    if (age.years > 1) yearString = " years";
    else yearString = " year";
    if (age.months > 1) monthString = " months";
    else monthString = " month";
    if (age.days > 1) dayString = " days";
    else dayString = " day";

    if (age.years > 0 && age.months > 0 && age.days > 0) {
      this.age = age.years + yearString + " old";
    } else if (age.years == 0 && age.months == 0 && age.days > 0) {
      this.age = age.days + dayString + " old";
    } else if (age.years > 0 && age.months == 0 && age.days == 0) {
      this.age = age.years + yearString + " old";
    } else if (age.years > 0 && age.months > 0 && age.days == 0) {
      this.age = age.years + yearString + " old";
    } else if (age.years == 0 && age.months > 0 && age.days > 0) {
      this.age = age.months + monthString + " old";
    } else if (age.years > 0 && age.months == 0 && age.days > 0) {
      this.age = age.years + yearString + " old";
    } else if (age.years == 0 && age.months > 0 && age.days == 0) {
      this.age = age.months + monthString + " old";
    } else {
      this.age = "0";
    }

    return this.age;
  }

  //Initializes the table with new data
  loadTable() {
    if (this.isDtInitialized) {
      this.dtElement.dtInstance.then((dtInstance: DataTables.Api) => {
        dtInstance.destroy();
        this.dtTrigger.next();
      });
    } else {
      this.isDtInitialized = true;
      this.dtTrigger.next();
    }
  }

  // set the current page info
  setPage() {
    // hold the child path
    const childPath = this.route.snapshot.routeConfig.path;
    switch (childPath) {
      case "amendments":
        this.page = "amendments";
        this.route.queryParams.subscribe((params) => {
          this.specimen.id = parseInt(params["id"]);
          this.specimen.pathology_number = params["pathology_number"];
        });
        this.parentUrl = this.parentUrl.slice(
          0,
          this.parentUrl.indexOf(childPath) - 1
        );
        break;
      case "archive":
        this.page = "archive";
        this.parentUrl = this.parentUrl.slice(
          0,
          this.parentUrl.indexOf(childPath) - 1
        );
        break;
      default:
        this.page = "root";
        break;
    }
  }

  // executes persists data based on the required action
  submit($event) {
    this.action = $event.action;
    this.specimen = $event.data;
    switch (this.action) {
      case "create":
        this.createSpecimen();
        break;
      case "edit":
        this.editSpecimen();
        break;
      // case "amend":
      //   this.amendSpecimen();
      //   break;
    }
  }

  //set Patient info for new Specimen Form
  setPatientInfo() {
    this.specimen.patient_id = this.patient.id;
    this.specimen.patient.id = this.specimen.patient_id;
    this.specimen.patient.patient_number = this.patient.patient_number;
    // this.specimen.patient.folder_number = this.patient.folder_number;
    // this.specimen.patient.pathology_number = this.patient.pathology_number;
    this.specimen.patient.reporting_date = this.patient.reporting_date;
    this.specimen.patient.first_name = this.patient.first_name;
    this.specimen.patient.last_name = this.patient.last_name;
    this.specimen.patient.date_of_birth = this.patient.date_of_birth;
    this.specimen.patient.age = this.patient.age;
    this.specimen.patient.age_option = this.patient.age_option;
    this.specimen.patient.gender = this.patient.gender;
    this.specimen.patient.email = this.patient.email;
    this.specimen.patient.address = this.patient.address;
    this.specimen.patient.phone = this.patient.phone;
    this.specimen.patient.national_health_insurance_id = this.patient.national_health_insurance_id;

    this.specimen.patient.allergies = this.patient?.allergies;
    this.specimen.patient.known_health_conditions = this.patient?.known_health_conditions;
    this.specimen.patient.cancer_status = this.patient?.cancer_status;
    this.specimen.patient.cancer_type = this.patient?.cancer_type;
    this.specimen.patient.mother_status = this.patient?.mother_status;
    this.specimen.patient.mother_known_health_conditions = this.patient?.mother_known_health_conditions;
    this.specimen.patient.mother_cancer_status = this.patient?.mother_cancer_status;
    this.specimen.patient.mother_cancer_type = this.patient?.mother_cancer_type;
    this.specimen.patient.father_status = this.patient?.father_status;
    this.specimen.patient.father_known_health_conditions = this.patient?.father_known_health_conditions;
    this.specimen.patient.father_cancer_status = this.patient?.father_cancer_status;
    this.specimen.patient.father_cancer_type = this.patient?.father_cancer_type;
    this.specimen.patient.blood_type = this.patient?.blood_type;
    this.specimen.patient.surgical_history = this.patient?.surgical_history;
    this.specimen.patient.tobacco = this.patient?.tobacco;
    this.specimen.patient.alcohol = this.patient?.alcohol;
    this.specimen.patient.drug_abuse = this.patient?.drug_abuse;
    this.specimen.patient.sexual_activity = this.patient?.sexual_activity;
  }

  // set action to view,set data and if any amendments have been made
  async view(selected_specimen) {
    this.spinner.show();
    console.log(selected_specimen);
    this.specimen = (await this.getSpecimen(selected_specimen.id))["data"];
    this.files.push(this.specimen.attachments);
    this.action = "view";
    this.viewModal.show();
    this.spinner.hide();
  }

  // set action to amend
  amend() {
    this.spinner.show();
    this.action = "amend";
    this.spinner.hide();
  }

  // set action to create and set initial data
  create() {
    this.spinner.show();
    this.specimen = { user: {}, patient: {} };
    this.setPatientInfo();
    this.action = "create";
    this.form.show();
    this.spinner.hide();
  }

  // set action to edit and set initial data
  async edit(selected_specimen) {
    this.spinner.show();
    this.specimen = (await this.getSpecimen(selected_specimen.id))["data"];
    console.log(this.specimen);
    this.action = "edit";
    this.form.show();
    this.spinner.hide();
  }

  // show the delete dialog and performs the deletion (softDelete|permanentDelete)
  delete(selected_specimen) {
    // Set the default alert options
    let alertObject: SweetAlertOptions = {
      title: "Are you sure?",
      type: "warning",
      showCloseButton: true,
      showCancelButton: true,
    };
    // Sets the alert text
    alertObject.text =
      this.page == "archive"
        ? "Once deleted, you will not be able to recover record!"
        : "This record will be deleted and moved to archives";

    Swal.fire(alertObject).then((willDelete) => {
      if (!willDelete.dismiss) {
        Swal.fire({
          text: "Poof! Record has been deleted!",
          type: "success",
          showConfirmButton: false,
          timer: 1500,
        });
        this.specimen = selected_specimen;
        this.page == "archive"
          ? this.permamentDeleteSpecimen()
          : this.softDeleteSpecimen();
      }
    });
  }

  // executes restore function to reserve temporary deletion
  restore(selected_specimen) {
    this.spinner.show();
    this.specimen = selected_specimen;
    this.restoreSpecimen();
    this.spinner.hide();
  }

  // get list of all patients
  getPatients(query = "") {
    this.auth.get("patients?query=" + query).subscribe(
      (response) => {
        // console.log(response);
        if (response["data"] !== null || response["data"] !== undefined) {
          this.spinner.hide();
          this.patients = response["data"];
          this.patientsBuffer = this.patients.slice(0, this.bufferSize);
        }
      },
      (error) => {
        this.spinner.hide();
        this.alert.error("Error loading patient specimen Data");
        // // console.log(error);
      }
    );
  }

  // get selected patient from the dropdown
  async patientSelected() {
    if (this.selected_patient === null) {
      this.isSelected = false;
    } else {
      this.patient = (await this.getPatient(this.selected_patient))["data"][
        "patient"
      ];
      this.isSelected = true;
    }
  }

  // Check if file has any amendments
  async getPatient(id) {
    return await this.auth.get("patient_info/" + id).toPromise();
  }

  searchChange($event) {}

  // Get company profile picture
  getComProfile() {
    this.spinner.show();
    this.auth.get("facility_profile").subscribe(
      (response) => {
        if (response["company"] !== null) {
          this.comData = response["company"];
          this.spinner.hide();
        } else {
          // this.alert.info('Response was null');
          this.spinner.hide();
        }
      },
      (error) => {
        this.spinner.hide();
        // // console.log(error);
      }
    );
  }

  // Check if file has any amendments
  checkAmendment(id) {
    this.auth.show("general_practices_amend", id).subscribe(
      (response) => {
        if (Object.keys(response["data"]).length) {
          this.isAmended = true;
        } else {
          this.isAmended = false;
        }
      },
      (error) => {
        // // console.log(error);
      }
    );
  }

  async getSpecimen(id) {
    return await this.auth.get("consultation_admission/" + id).toPromise();
  }

  // Get list of all specimen
  async getSpecimens() {
    this.spinner.show();
    this.dtOptions.ajax = (dataTablesParameters: any, callback) => {
      this.auth
        .get("consultation_admission?" + this.serialize(dataTablesParameters))
        .subscribe((resp) => {
          this.specimens = resp["data"];
          // console.log(resp);
          callback({
            recordsTotal: resp["recordsTotal"],
            recordsFiltered: resp["recordsFiltered"],
            data: [],
          });
        });
    };
    let table = await this.dtElement.dtInstance;
    table.ajax.reload();
  }

  async getSpecimenArchives() {
    this.spinner.show();
    this.dtOptions.ajax = (dataTablesParameters: any, callback) => {
      this.auth
        .get(
          "consultation_admission_view_softdelete?" +
            this.serialize(dataTablesParameters)
        )
        .subscribe((resp) => {
          this.specimens = resp["data"];
          // console.log(resp);
          callback({
            recordsTotal: resp["recordsTotal"],
            recordsFiltered: resp["recordsFiltered"],
            data: [],
          });
        });
    };
    let table = await this.dtElement.dtInstance;
    table.ajax.reload();
  }

  // // Get list of all specimen
  // getSpecimens() {
  //   this.spinner.show();
  //   this.auth.get("consultation_admission").subscribe(
  //     (response) => {
  //       if (
  //         response["consultation_admission"] !== null ||
  //         response["consultation_admission"] !== undefined
  //       ) {
  //         this.spinner.hide();
  //         this.specimens = response["data"];
  //         // // console.log(this.specimens);
  //       } else {
  //         this.alert.info("No data found.");
  //       }
  //       this.loadTable();
  //     },
  //     (error) => {
  //       this.spinner.hide();
  //       this.alert.error("Error loading Data");
  //       // // console.log(error);
  //     }
  //   );
  // }

  // // Get list of all specimen archives
  // getSpecimenArchives() {
  //   this.spinner.show();
  //   this.auth.get("consultation_admission_view_softdelete").subscribe(
  //     (response) => {
  //       this.spinner.hide();
  //       if (response["data"] !== null || response["data"] !== undefined) {
  //         this.specimens = response["data"];
  //       } else {
  //         this.alert.info("No data found.");
  //       }
  //       this.loadTable();
  //     },
  //     (error) => {
  //       this.spinner.hide();
  //       this.alert.error("Error loading Endometrial Cancer Data");
  //       // // console.log(error);
  //     }
  //   );
  // }

  // Get list of all specimen amendments
  getSpecimenAmendments() {
    this.spinner.show();
    this.auth.show("consultation_admission_amend", this.specimen.id).subscribe(
      (response) => {
        // // console.log(response["data"]);
        this.spinner.hide();
        if (
          response["data"] !== null &&
          response["data"] !== undefined &&
          response["data"].length > 0
        ) {
          // // console.log('Found data successfully');
          this.specimens = response["data"];
        } else {
          this.alert.info("No data found.");
        }
        this.loadTable();
      },
      (error) => {
        this.spinner.hide();
        this.alert.error("Error loading Request Data");
        // // console.log(error);
      }
    );
  }

  // function to create a new specimen form
  createSpecimen() {
    this.spinner.show();
    // // console.log(this.specimen);
    this.auth.store("consultation_admission", this.specimen).subscribe(
      (response) => {
        // // console.log(response);
        if (response !== null || response !== undefined) {
          this.spinner.hide();
          this.getSpecimens();
          this.alert.success(response["message"]);
        }
      },
      (error) => {
        // // console.log(error);
        this.spinner.hide();
        if (error.status === 500) {
          this.alert.warning("Internal Server Error");
        } else {
          this.alert.error("Can`t create a request now. Try again later");
        }
      }
    );
  }

  // function to edit a specimen form
  editSpecimen() {
    this.spinner.show();
    this.auth
      .update("consultation_admission", this.specimen.id, this.specimen)
      .subscribe(
        (response) => {
          // // console.log(response);
          if (response !== null || response !== undefined) {
            this.spinner.hide();
            this.getSpecimens();
            this.alert.success(response["message"]);
          }
        },
        (error) => {
          // // console.log(error);
          this.spinner.hide();
          if (error.status === 500) {
            this.alert.warning("Internal Server Error");
          } else {
            this.alert.error("Can`t create a request now. Try again later");
          }
        }
      );
  }

  // // function to amend a specimen form
  // amendSpecimen() {
  //   this.spinner.show();
  //   // // console.log(this.mastectomyAmendDetails);
  //   this.auth.store("consultation_admission_amend", this.specimen).subscribe(
  //     (response) => {
  //       // // console.log(response);
  //       if (response !== null || response !== undefined) {
  //         this.spinner.hide();
  //         this.getSpecimens();
  //         this.alert.success(response["message"]);
  //       }
  //     },
  //     (error) => {
  //       // // console.log(error);
  //       this.spinner.hide();
  //       if (error.status === 500) {
  //         this.alert.warning("Internal Server Error");
  //       } else {
  //         this.alert.error("Can`t create a request now. Try again later");
  //       }
  //     }
  //   );
  // }

  // Soft-Deleting data of a specific specimen
  softDeleteSpecimen() {
    this.spinner.show();
    this.auth
      .destroy("consultation_admission_softdelete", this.specimen.id)
      .subscribe(
        (response) => {
          this.spinner.hide();
          this.alert.success(response["message"]);
          this.getSpecimens();
        },
        (error) => {
          // // console.log(error);
          this.spinner.hide();
          this.alert.error("Error deleting data, please try again.");
        }
      );
  }

  // Permanently Deleting data of a specific specimen
  permamentDeleteSpecimen() {
    this.spinner.show();
    this.auth
      .destroy("consultation_admission_delete_softdelete", this.specimen.id)
      .subscribe(
        (response) => {
          this.spinner.hide();
          this.alert.success(response["message"]);
          this.getSpecimenArchives();
        },
        (error) => {
          // // console.log(error);
          this.spinner.hide();
          this.alert.error("Error deleting data, please try again.");
        }
      );
  }

  // function to restore softDeleted specimen
  restoreSpecimen() {
    this.spinner.show();
    this.auth
      .restore("consultation_admission_restore_softdelete", this.specimen.id)
      .subscribe(
        (response) => {
          // // console.log(response);
          this.spinner.hide();
          this.alert.success(response["message"]);
          this.getSpecimenArchives();
        },
        (error) => {
          this.spinner.hide();
          // // console.log(error);
          this.alert.error("Could not update info, please try again later");
        }
      );
  }

  pushFiles(event: any = {}): Promise<void> {
    // console.log(this.files);
    // console.log(event);
    this.uploaded.emit({
      files_payload: this.files,
    });
    return Promise.all(
      _.map(event.target.files, (file: any) => {
        return this.pushFileToScope(file);
      })
    ).then(() => {
      event.target.value = "";
    });
  }

  pushFileToScope(file: File): Promise<void> {
    return this.fileUploadService
      .uploadFile(file)
      .then((uploadedFile) => {
        this.files.push(uploadedFile);
        // // console.log(this.files);
      })
      .catch(() => {});
  }

  // Print to PDF function
  printMe() {
    printElement(document.getElementById("printThis"));
    function printElement(elem) {
      const domClone = elem.cloneNode(true);

      const $printSection = document.getElementById("printSection");

      if (!$printSection) {
        const $printSection = document.createElement("div");
        $printSection.id = "printSection";
        document.body.appendChild($printSection);
      }

      $printSection.innerHTML = "";
      $printSection.appendChild(domClone);
      window.print();
    }
  }
}
