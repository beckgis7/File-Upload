import {
  Component,
  OnInit,
  ViewChild,
  Output,
  EventEmitter,
  Input,
  ElementRef,
} from "@angular/core";
import { AuthenticationService } from "src/app/others/services/authentication.service";
import { AlertService } from "src/app/others/services/alert.service";
import { UiModalComponent } from "src/app/theme/shared/components/modal/ui-modal/ui-modal.component";
import { FormGroup, FormBuilder, FormArray, Validators } from "@angular/forms";
import { NgxSpinnerService } from "ngx-spinner";
import * as _ from "lodash";
import { DomSanitizer } from '@angular/platform-browser';
// import { NgbDateStruct } from "@ng-bootstrap/ng-bootstrap";

@Component({
  selector: "app-consultation-form",
  templateUrl: "./consultation-form.component.html",
  styleUrls: ["./consultation-form.component.scss"],
})
export class ConsultationFormComponent implements OnInit {
  @ViewChild("formModal") modal: UiModalComponent;
  @Output() submited = new EventEmitter();
  @Input() action: string;
  @Input() specimen: any;
  @ViewChild("requestAttachmentFiles", { static: false })
  requestAttachmentFiles: ElementRef;

  title: string;
  case_number: any;
  activated: boolean = false;
  attach: Array<any> = [];

  // public model: NgbDateStruct;
  public isCollapsed: boolean;
  public multiCollapsed1: boolean;
  public multiCollapsed2: boolean;

  collapse(elem) {
    // Check if elem is closed a.k.a collapsed
    if (document.getElementById(elem).classList.value == "card closed") {
      document.getElementById(elem).classList.remove("closed");
      document
        .querySelector("#" + elem + " .card-header i")
        .classList.remove("icon-chevron-down");
      document
        .querySelector("#" + elem + " .card-header i")
        .classList.add("icon-chevron-up");
    } else {
      document.getElementById(elem).classList.add("closed");
      document
        .querySelector("#" + elem + " .card-header i")
        .classList.remove("icon-chevron-up");
      document
        .querySelector("#" + elem + " .card-header i")
        .classList.add("icon-chevron-down");
    }
  }

  // Formgroups
  form: FormGroup;
  requestForm: FormGroup;

  keyword = "";

  errorMsg: string;
  isLoadingResult: boolean;

  isFound = false;
  search = "";
  searchSymptom = "";
  searchLoinc = "";
  drugSearch = "";
  isFoundSym = false;
  isFoundLonic = false;
  isFoundMed = false;
  isChosenMed = false;

  vital: any;
  vitals: any;

  recommend = "";
  planned = "";

  isLoading = false;
  isSelected = false;
  exist = false;

  config = {
    displayKey: "item", // if objects array passed which key to be displayed defaults to description
    search: true,
    limitTo: 10,
  };
  health_conditions = [
    "Asthma",
    "Diabetes",
    "High Cholesterol",
    "High Blood Pressure",
  ];
  // boolean varaibles
  // Dropdown options
  known_health_conditions: any = [];
  mother_known_health_conditions: any = [];
  father_known_health_conditions: any = [];
  PsShow = false;
  hsShow = false;
  Age = 0;
  preTherapyShow = false;
  tumourInvolveShow = false;
  otherShow = false;
  tumourShow = false;
  metastasis = false;
  Polyp = false;
  other_specify = false;
  hasCancer = false;
  hasCancerFather = false;
  hasCancerMother = false;

  // ICD
  iCDcodes: any;
  iCDsymptoms: any;
  lonicCodes: any;
  meds: any;
  allMedicines: any;

  // Multiselect Codes
  onItemSelect(item: any) {
    // // console.log(item);
  }
  onSelectAll(items: any) {
    // // console.log(items);
  }

  setTitle() {
    switch (this.action) {
      case "create":
        this.getCase();
        this.title = "Add New Case";
        // // console.log(this.specimen.patient);
        break;
      case "edit":
        this.title = "Edit Case";
        // this.getFile();
        this.case_number = this.specimen.case_id;
        // console.log(this.specimen.patient);
        break;
      case "amend":
        this.title = "Amend Case";
        this.case_number = this.specimen.case_id;
        break;
      default:
        this.title = "Add New Case";
    }
  }

  // GENERATE CASE NUMBER
  getCase() {
    // this.spinner.show();
    this.auth.get("consultation_admission_caseid").subscribe((response) => {
      // // console.log(response);
      if (response["data"] !== null || response["data"] !== undefined) {
        // this.spinner.hide();
        this.case_number = response["data"];
        // // console.log(this.case_number);
      } else {
        this.alert.info("No data found.");
      }
    });
  }

  show() {
    this.activated = true;
    this.modal.show();
  }
  submit() {
    switch (this.action) {
      case "create":
        this.setData();
        break;
      case "edit":
        this.setData();
        break;
      case "amend":
        this.setAmendmentData();
        break;
      default:
        this.setData();
    }
    this.submited.emit({
      action: this.action,
      data: this.specimen,
    });
  }

  url: any = "";
  url2: any = "";
  url3: any = "";
  fileNames = "";
  fileNames2 = "";
  fileNames3 = "";
  userID = sessionStorage.getItem("userID");
  user = {};
  disableSubmitButton = false;

  // Form Data
  formType = "";
  typeOfRequest = "";
  otherTypeOfRequest = "";
  details = "";
  base64file = "";
  attachment: any;
  attachment2: any;
  attachment3: any;
  attachmenttype: any;
  attachment2type: any;
  attachment3type: any;

  files: File[] = [];

  constructor(
    private formBuilder: FormBuilder,
    private alert: AlertService,
    private spinner: NgxSpinnerService,
    private auth: AuthenticationService,
    private sanitizer: DomSanitizer
  ) {}

  ngOnInit() {
    this.form = this.formBuilder.group({
      patient: this.formBuilder.group({
        patient_number: [{ value: null, disabled: true }],
        // folder_number: [{ value: null, disabled: true }],
        // pathology_number: [{ value: null, disabled: true }],
        reporting_date: [{ value: null, disabled: true }],
        first_name: [{ value: null, disabled: true }],
        last_name: [{ value: null, disabled: true }],
        date_of_birth: [{ value: null, disabled: true }],
        age: [{ value: null, disabled: true }],
        age_option: [{ value: null, disabled: true }],
        gender: [{ value: null, disabled: true }],
        email: [{ value: null, disabled: true }],
        address: [{ value: null, disabled: true }],
        phone: [{ value: null, disabled: true }],
        national_health_insurance_id: [{ value: null, disabled: true }],

        allergies: [{ value: null, disabled: true }],
        known_health_conditions: [{ value: null, disabled: true }],
        cancer_status: [{ value: null, disabled: true }],
        cancer_type: [{ value: null, disabled: true }],
        mother_status: [{ value: null, disabled: true }],
        mother_known_health_conditions: [{ value: null, disabled: true }],
        mother_cancer_status: [{ value: null, disabled: true }],
        mother_cancer_type: [{ value: null, disabled: true }],
        father_status: [{ value: null, disabled: true }],
        father_known_health_conditions: [{ value: null, disabled: true }],
        father_cancer_status: [{ value: null, disabled: true }],
        father_cancer_type: [{ value: null, disabled: true }],
        blood_type: [{ value: null, disabled: true }],
        surgical_history: [{ value: null, disabled: true }],
        tobacco: [{ value: null, disabled: true }],
        alcohol: [{ value: null, disabled: true }],
        drug_abuse: [{ value: null, disabled: true }],
        sexual_activity: [{ value: null, disabled: true }],
      }),
      folder_number: [null],
      weight_result: [""],
      weight_measure: [""],

      height_result: [""],
      height_measure: [""],

      at_age_result: [""],
      at_age_measure: [""],

      heart_result: [""],
      heart_measure: [""],
      heart_range: [""],
      heart_abnormal: [""],

      temp_result: [""],
      temp_measure: [""],
      temp_range: [""],
      temp_abnormal: [""],

      oxygen_result: [""],
      oxygen_measure: [""],
      oxygen_range: [""],
      oxygen_abnormal: [""],

      systolic_result: [""],
      systolic_measure: [""],
      diastolic_result: [""],
      diastolic_measure: [""],

      glucose_result: [""],
      glucose_measure: [""],
      glucose_range: [""],
      glucose_abnormal: [""],

      respiratory_result: [""],
      respiratory_measure: [""],

      head_result: [""],
      head_measure: [""],
      head_range: [""],
      head_abnormal: [""],

      bmi_result: [""],
      bmi_measure: [""],
      bmi_range: [""],
      bmi_abnormal: [""],

      visit_reason: [""],
      problem_desc: [""],
      problem_notes: [""],
      problem_free_test: [""],

      symptoms_icd: [""],
      symptoms_desc: [""],

      test_order: [""],
      test_free_test: [""],
      medication_search: [""],
      medication_strength: [""],
      medication_quantity: [""],
      medication_direction: [""],
      medication_free_test: [""],

      recommendation: [""],
      schedule_date: [""],
      schedule: [""],
      adm_ward: [""],
      adm_planned_pro: ["surgery"],
      adm_notes: [""],
      planned_surgery: [""],
      planned_other: [""],
      other_specify: [""],

      comments: [""],
      gp: [""],

      icd_search: null,
      loinc_search: null,
      rxnorm_medication: null,
      chosen_medication: null,
      // attachments: [],
      // attachments: this.formBuilder.array([]),

      // attachments1: [""],
      // attachments2: [""],
      // attachments3: [""],
    });
  }

  ngDoCheck() {
    if (this.activated) {
      this.prepareForm();
      this.activated = false;
    }
  }

  prepareForm() {
    this.setTitle();
    Object.keys(this.specimen).forEach((key) => {
      let control = this.form.get(key);
      if (control) {
        if (
          this.specimen[key] !== null &&
          typeof this.specimen[key] === "object"
        ) {
          Object.keys(this.specimen[key]).forEach((key1) => {
            if (control.get(key1)) {
              // // console.log(control.get(key1));
              control.get(key1).setValue(this.specimen[key][key1]);
            }
          });
        } else {
          control.setValue(this.specimen[key]);
        }
      }
    });
    this.fileNames = this.specimen?.attachments1;
    this.fileNames2 = this.specimen?.attachments2;
    this.fileNames3 = this.specimen?.attachments3;

    // // console.log(this.specimen);
  }

  setData() {
    this.specimen.user_id = sessionStorage.getItem("userID");
    this.specimen.user.surname = sessionStorage.getItem("surname");
    this.specimen.user.othernames = sessionStorage.getItem("username");
    this.specimen.case_id = this.case_number;
    this.specimen.subdomain = sessionStorage.getItem("subdomain");

    Object.keys(this.form.controls).forEach((key) => {
      this.specimen[key] = this.form.controls[key].value;
    });

    // Check if user added attachments to request
    this.attach != undefined ? (this.specimen.attachments = this.attach) : "";
  }

  setAmendmentData() {
    this.specimen.amender_id = sessionStorage.getItem("userID");
    this.specimen.general_practice_file_id = this.specimen.id;
    this.setData();
  }

  handleDateClick(arg) {
    // // console.log(arg);
  }
  ///////////////////////////////// ICD APIS ///////////////////////////
  getIcdCode(data) {
    if (this.search === "") {
      this.clearSearch();
    } else if (data === "" || data === null) {
      this.clearSearch();
      return;
    } else {
      this.auth.getICD(data).subscribe(
        (response) => {
          // this.account_name = response["data"]["account_name"];
          // // console.log(response);
          // // console.log(response);
          this.iCDcodes = response[3];
          this.isFound = true;
        },
        (error) => {
          // this.alert.error(error['message']);
          if (error.status === 500) {
            this.alert.warning("Internal Server Error");
          } else {
            this.alert.error("Can`t create a request now. Try again later");
          }
        }
      );
    }
  }

  setICD(data) {
    // // console.log(data);
    this.search = data;
    this.clearSearch();
  }

  clearSearch() {
    this.isFound = false;
  }

  getIcdSymptom(data) {
    if (this.searchSymptom === "") {
      this.clearSymptomSearch();
    } else if (data === "" || data === null) {
      this.clearSymptomSearch();
      return;
    } else {
      this.auth.getICD(data).subscribe(
        (response) => {
          this.iCDsymptoms = response[3];
          this.isFoundSym = true;
        },
        (error) => {
          this.isFoundSym = false;
          // this.alert.error(error['message']);
          if (error.status === 500) {
            this.alert.warning("Internal Server Error");
          } else {
            this.alert.error("Can`t create a request now. Try again later");
          }
        }
      );
    }
  }

  setICDSymptom(data) {
    // // console.log(data);
    this.searchSymptom = data;
    this.clearSymptomSearch();
  }

  clearSymptomSearch() {
    this.isFoundSym = false;
  }

  ///////////////////////////////// LOINC APIS ///////////////////////////
  getLoincItem(value) {
    if (this.searchLoinc === "") {
      this.clearLonicSearch();
    } else if (value === "" || value === null) {
      this.clearLonicSearch();
      return;
    } else {
      this.auth.getLoinc(value).subscribe(
        (response) => {
          this.lonicCodes = response[3];
          // // console.log(this.lonicCodes);
          this.isFoundLonic = true;
        },
        (error) => {
          this.isFoundLonic = false;
          // this.alert.error(error['message']);
          if (error.status === 500) {
            this.alert.warning("Internal Server Error");
          } else {
            this.alert.error("Can`t create a request now. Try again later");
          }
        }
      );
    }
  }

  setLonic(data) {
    // // console.log(data);
    this.searchLoinc = data;
    this.clearLonicSearch();
  }

  clearLonicSearch() {
    this.isFoundLonic = false;
  }

  /////////////////////////////// RXNORM API ///////////////////////////////////////////////////////
  getDrug(value) {
    if (this.drugSearch === "") {
      this.clearMedSearch();
    } else if (value === "" || value === null) {
      this.clearMedSearch();
      return;
    } else {
      this.auth.getDrug(value).subscribe(
        (response) => {
          // console.log(response)
          this.isFoundMed = true;
          this.meds = response["drugGroup"]["conceptGroup"];
          // // console.log(response['drugGroup']['conceptGroup']);
          // // console.log( response["drugGroup"]["conceptGroup"][0]["conceptProperties"] );
          // this.isName = true;
        },
        (error) => {
          this.isFoundMed = false;
          // this.alert.error(error['message']);
          if (error.status === 500) {
            this.alert.warning("Internal Server Error");
          } else {
            this.alert.error("Can`t create a request now. Try again later");
          }
        }
      );
    }
  }

  clearMedSearch() {
    this.isFoundMed = false;
  }

  hideMed() {
    this.isChosenMed = false;
  }

  // selecting medication types
  medType(data) {
    if (data === "SBD") {
      // // console.log(data);
      this.allMedicines = this.meds[2]["conceptProperties"];
      this.isChosenMed = true;
    } else if (data === "BPCK") {
      // // console.log(data);
      this.allMedicines = this.meds[0]["conceptProperties"];
      this.isChosenMed = true;
    } else if (data === "SCD") {
      // // console.log(data);
      this.allMedicines = this.meds[3]["conceptProperties"];
      this.isChosenMed = true;
    } else {
      // // console.log(data);
      this.allMedicines = this.meds[1]["conceptProperties"];
      this.isChosenMed = true;
    }
  }

  onSelect(event) {
    // console.log(event);
    this.files.push(...event.addedFiles);
    if (this.files && this.files.length >= 2) {
      this.onRemove(this.files[0]);
    }
    // const formData = new FormData();

    for (var i = 0; i < this.files.length; i++) {
      this.specimen.append("attachments[]", this.files[i]);
    }

    // this.auth.post("http://localhost:8001/upload.php", formData)
    //   .subscribe((res) => {
    //     // console.log(res);
    //     alert("Uploaded Successfully.");
    //   });
    // console.log(this.form);
  }

  onRemove(event) {
    // console.log(event);
    this.files.splice(this.files.indexOf(event), 1);
  }

  // Functions for add and removing Medication and Liquid Intakes

  attachments(): FormArray {
    return this.form.get("attachments") as FormArray;
  }

  newFile(): FormGroup {
    return this.formBuilder.group({
      file_link: "",
    });
  }
  getFile() {
    if (this.specimen.attachments.length == 0) {
      this.attachments().push(this.newFile());
    } else {
      this.specimen.attachments.forEach((data) => {
        this.attachments().push(
          this.formBuilder.group({
            file_link: data.file_link,
          })
        );
      });
    }
  }

  addFile() {
    // this.url = "";
    // this.fileNames = "";
    // this.attachment = "";
    // this.attachmenttype = "";
    this.attachments().push(this.newFile());
  }

  removeFile(i: number) {
    this.attachments().removeAt(i);
  }

  onSubmit() {
    // console.log(this.form.value);
  }

  //..............................1.........................................
  getFiles() {
    document.getElementById("requestAttachmentFiles").click();
  }

  // Set  file names
  setFileNames() {
    // Reset file names
    this.fileNames = "";
    this.attachment = "";
    this.fileNames = document.getElementById("requestAttachmentFiles")[
      "files"
    ][0].name;
    this.attachmenttype = document.getElementById("requestAttachmentFiles")[
      "files"
    ][0].type;
  }

  onSelectFile(event: any) {
    if (this.attachmenttype == "application/pdf") {
      this.url = "./../../../../../assets/images/pdf.png";
    } else {
      if (event.target.files && event.target.files[0]) {
        var reader = new FileReader();

        reader.readAsDataURL(event.target.files[0]); // read file as data url

        reader.onload = (event) => {
          // called once readAsDataURL is completed
          this.url = event.target.result;
        };
      }
    }
  }

  fileChangeEvent(event: any) {
    const file = event.target.files[0];
    const reader = new FileReader();
    reader.onload = this.touchup.bind(this);
    reader.readAsBinaryString(file);
  }

  touchup(data) {
    const binaryString = data.target.result;
    if (this.attachmenttype == "application/pdf") {
      this.attachment = "data:application/pdf;base64," + btoa(binaryString);
    } else {
      this.attachment = "data:image/jpeg;base64," + btoa(binaryString);
    }
  }
  //..............................1.........................................
  async upload($event) {
    this.attach = await $event.files_payload;
    console.log(this.attach);
  }
}
