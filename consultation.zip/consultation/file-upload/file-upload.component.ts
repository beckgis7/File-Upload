import { Component, OnInit, Output, EventEmitter, Input } from "@angular/core";
import { FileUploadService } from '../services/file-upload.service';
import * as _ from 'lodash';
const FileSaver = require('file-saver');
import { DomSanitizer } from '@angular/platform-browser';

@Component({
  selector: "file-upload",
  templateUrl: "file-upload.component.html",
  styleUrls: ["file-upload.component.scss"],
})
export class FileUploadComponent implements OnInit {
  @Output() uploaded = new EventEmitter();
  @Input() attachData: Array<any> = [];
  files: Array<any> = [];

  constructor(
    private fileUploadService: FileUploadService,
    private sanitizer: DomSanitizer
  ) {}

  ngOnInit(): void {
    console.log(this.attachData);
    this.files.push(this.attachData);
    this.uploaded.emit({
      files_payload: this.files
    });
  }

  pushFiles(event: any = {}): Promise<void> {
    // console.log(this.files);
    // console.log(event);
    this.uploaded.emit({
      files_payload: this.files,
    });
    return Promise.all(
      _.map(event.target.files, (file: any) => {
        return this.pushFileToScope(file);
      })
    ).then(() => {
      event.target.value = "";
    });
  }

  removeFile(index: number): void {
    this.files.splice(index, 1);
    this.uploaded.emit({
      files_payload: this.files,
    });
  }
  removeAllFiles(): void {
    this.files.length = 0;
    this.uploaded.emit({
      files_payload: this.files,
    });
  }

  downloadFile(index: number): Promise<Object> {
    let file = this.files[index];

    // You have two options here
    // 1. To get content from server
    // 2. By direct path to file

    if (file.content) {
      let blob = new Blob([file.content], { type: file.type });

      // https://www.npmjs.com/package/file-saver
      FileSaver.saveAs(blob, file.name);

      return Promise.reject({});
    }

    let image = this.sanitizer.bypassSecurityTrustResourceUrl(
      file.preview.backgroundImage
    );

    // // console.log(file.preview.backgroundImage);
    return Promise.resolve("https://" + image);
    // return Promise.resolve('https://static.pexels.com/photos/38136/pexels-photo-38136.jpeg');
  }

  pushFileToScope(file: File): Promise<void> {
    return this.fileUploadService
      .uploadFile(file)
      .then((uploadedFile) => {
        this.files.push(uploadedFile);
        // // console.log(this.files);
      })
      .catch(() => {});
  }
}
